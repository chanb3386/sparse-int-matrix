public class MatrixEntry {

    private int row;
    private int col;
    private int data;
    private MatrixEntry rowReference;
    private MatrixEntry colReference;


    public MatrixEntry(int row, int col, int data) {
        this.row = row;
        this.col = col;
        this.data = data;       // Data equals number associated
    }

    public int getColumn(){
        return col;
    }

    public void setColumn(int col){
        this.col = col;
    }

    public int getRow(){
        return row;
    }

    public void setRow(int row){
        this.row = row;
    }

    public int getData(){
        return data;
    }

    public void setData(int data){
        this.data = data;
    }

    public MatrixEntry getNextRow(){
        //same column number
        //different row number ++
        return rowReference;
    }

    public void setNextRow(MatrixEntry el){
        rowReference = el;
    }

    public MatrixEntry getNextCol(){
        //Same row
        //different col number ++
        return colReference;
    }

    public void setNextCol(MatrixEntry el){
        colReference = el;
    }
}
